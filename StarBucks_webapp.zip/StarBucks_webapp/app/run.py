import json
import plotly
import pandas as pd

from flask import Flask
from flask import render_template, request, jsonify
from plotly.graph_objs import Bar, Line
import joblib



app = Flask(__name__)

# load data
df = pd.read_csv('../data/dff.csv')

# load model
model = joblib.load("../models/model.pkl")


# index webpage displays cool visuals and receives user input text for model
@app.route('/')
@app.route('/index')
def index():
    
    # extract data needed for visuals
    # TODO: Below is an example - modify to extract data for your own visuals
    new_reg = list(df['year'].value_counts().sort_index().values)
    year = list(df['year'].value_counts().sort_index().index)

    #add text length feature
    total_amount= list(df.groupby('gender').sum()['income'].values)
    gender= list(df.groupby('gender').sum()['income'].index)
    
    # create visuals
    # TODO: Below is an example - modify to create your own visuals
    graphs = [
        {
            'data': [
                Line(
                    x=year,
                    y=new_reg
                )
            ],

            'layout': {
                'title': 'loyalty program regestration per year',
                'yaxis': {
                    'title': "new members"
                },
                'xaxis': {
                    'title': "year"
                }
            }
        },
                {
            'data': [
                Bar(
                    x=gender,
                    y=total_amount
                )
            ],

            'layout': {
                'title': 'Total income per gender',
                'yaxis': {
                    'title': "income"
                },
                'xaxis': {
                    'title': "gender"
                }
            }
        }
    ]
    
    # encode plotly graphs in JSON
    ids = ["graph-{}".format(i) for i, _ in enumerate(graphs)]
    graphJSON = json.dumps(graphs, cls=plotly.utils.PlotlyJSONEncoder)
    
    # render web page with plotly graphs
    return render_template('master.html', ids=ids, graphJSON=graphJSON)


# web page that handles user query and displays model results
@app.route('/go')
def go():
    # save user input in query
    query = request.args.get('query', '') 
    query = query.split()
    person=[]
    # age income bogo bogo disc disc disc disc info info total_tra F M 2014 2015 2016 2017 2018
    # age income  offer total_tra gender year
    person.append(float(query[0]))
    person.append(float(query[1]))
    person+=offer_onehotencode(query[2])
    person.append(float(query[3]))
    person+=gender_onehotencode(query[4])
    person+=year_onehotencode(query[5])

    # use model to predict classification for query
    classification_labels = model.predict([person])[0]
    classification_results = {"interiact": classification_labels}

    # This will render the go.html Please see that file. 
    return render_template(
        'go.html',
        query=query,
        classification_result=classification_results
    )

def offer_onehotencode(offer_name):
    """
    return one-hot encoding for offers
    """
    offer=[0,0,0,0,0,0,0,0,0]
    if offer_name.lower() == 'bogo_10_5':
        return offer

    offers={'bogo_10_7':0,
            'bogo_5_5':1, 
            'bogo_5_7':2,
            'discount_10_10':3,
            'discount_10_7':4,
            'discount_20_10':5,
            'discount_7_7':6,
            'informational_0_3':7,
            'informational_0_4':8}

    offer[offers[offer_name.lower()]]+=1
    return offer

def gender_onehotencode(gender):
    """
    return one-hot encoding for gender
    """
    encode=[0,0]
    if gender.upper() == 'O':
        return encode

    genders={'F':0,
            'M':1}

    encode[genders[gender.upper()]]+=1
    return encode

def year_onehotencode(year):
    """
    return one-hot encoding for year
    """
    encode=[0,0,0,0,0]
    if year == '2013':
        return encode

    years={'2014':0,
            '2015':1, 
            '2016':2,
            '2017':3,
            '2018':4}

    encode[years[year]]+=1
    return encode

def main():
    app.run(host='0.0.0.0', port=3001, debug=True)


if __name__ == '__main__':
    main()